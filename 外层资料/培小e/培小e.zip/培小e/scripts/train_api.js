// =====================================================
// train_api.js —— 培小e 培训数据接口客户端
// 对接 4 个真实 JSON 接口：
//   query   → /api/HuangDao/training/query   (分页查询)
//   create  → /api/HuangDao/training/create  (新增/更新 UPSERT)
//   update  → /api/HuangDao/training/update  (按主键修改)
//   delete  → /api/HuangDao/training/delete  (软删除)
// 认证：Header Authorization + body account/credential
// =====================================================
const CFG = require('./config');

// 构建统一认证参数
function buildAuth(account, credential) {
  // 缺省时使用管理员凭据
  return {
    account: account || CFG.admin.account || 'admin',
    credential: credential || CFG.admin.credential || '',
  };
}

// 统一请求封装
async function request(method, body) {
  const baseUrl = CFG.api.baseUrl;
  const apiSecret = CFG.api.apiSecret;

  if (!baseUrl) {
    console.error('[培小e] 接口地址未配置：请到 scripts/config.js 设置 api.baseUrl');
    return { ok: false, error: 'API_NOT_CONFIGURED', body };
  }
  if (!apiSecret) {
    console.error('[培小e] apiSecret 未配置：请到 scripts/config.js 设置 api.apiSecret');
    console.error('[培小e] 请求载荷预览:', JSON.stringify(body, null, 2));
    return { ok: false, error: 'API_SECRET_NOT_CONFIGURED', body };
  }

  const url = `${baseUrl}/${method}`;
  // 请求超时（默认 30s），避免接口异常时脚本挂死
  const timeoutMs = CFG.api.timeoutMs || 30000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiSecret,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await resp.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return { ok: false, httpStatus: resp.status, code: -1, message: `响应非 JSON: ${text.slice(0, 200)}`, raw: text };
    }
    // 业务失败判定：HTTP 非 2xx，或业务 code 非 0（后端鉴权/参数错误常返回 HTTP 200 + code!=0，
    // 若只看 HTTP 状态会把「身份校验失败」等误判为成功，导致 queryAll 拿到空数据却不报错）
    const success = resp.ok && (json.code === 0 || json.code === '0' || json.code === undefined || json.code === null);
    if (!success) {
      return { ok: false, httpStatus: resp.status, code: json.code, message: json.message, raw: json };
    }
    return { ok: true, code: json.code, data: json.data, message: json.message, raw: json };
  } catch (e) {
    if (e.name === 'AbortError' || controller.signal.aborted) {
      return { ok: false, error: `请求超时(${timeoutMs}ms): ${url}`, timedOut: true };
    }
    return { ok: false, error: e.message, cause: e.cause?.message || '' };
  } finally {
    clearTimeout(timer);
  }
}

// 分页查询
//   options: { table, filters, columns, pageNum, pageSize, orderBy, orderDirection, account, credential }
async function query(options = {}) {
  const auth = buildAuth(options.account, options.credential);
  const body = {
    account: auth.account,
    credential: auth.credential,
    table: options.table || CFG.tables.record,
    filters: options.filters || [],
    pageNum: options.pageNum || 1,
    pageSize: options.pageSize || 20,
  };
  if (options.columns) body.columns = options.columns;
  if (options.orderBy) body.orderBy = options.orderBy;
  if (options.orderDirection) body.orderDirection = options.orderDirection;

  const result = await request('query', body);
  if (result.ok && result.data) {
    result.rows = result.data.rows || [];
    result.total = result.data.total || 0;
    result.pageNum = result.data.pageNum || 1;
  }
  return result;
}

// 新增或更新（UPSERT）
//   options: { table, values（单条）| rows（批量，最多500条）, account, credential }
async function create(options = {}) {
  const auth = buildAuth(options.account, options.credential);
  const body = {
    account: auth.account,
    credential: auth.credential,
    table: options.table || CFG.tables.record,
  };
  if (options.values) body.values = options.values;
  if (options.rows) body.rows = options.rows;

  return await request('create', body);
}

// 修改（按主键 EQ 定位，修改指定字段）
//   options: { table, filters（须含主键EQ）, values（仅要改的字段）, account, credential }
async function update(options = {}) {
  const auth = buildAuth(options.account, options.credential);
  const body = {
    account: auth.account,
    credential: auth.credential,
    table: options.table || CFG.tables.record,
    filters: options.filters || [],
    values: options.values || {},
  };
  return await request('update', body);
}

// 软删除（del_flag=2）
//   options: { table, filters（须含主键EQ）, account, credential }
async function del(options = {}) {
  const auth = buildAuth(options.account, options.credential);
  const body = {
    account: auth.account,
    credential: auth.credential,
    table: options.table || CFG.tables.record,
    filters: options.filters || [],
  };
  return await request('delete', body);
}

// 快捷工具：获取某表全部数据（自动翻页，管理员身份）
async function queryAll(table, filters = [], account, credential) {
  const allRows = [];
  let page = 1;
  const pageSize = 500;
  while (true) {
    const r = await query({ table, filters, pageNum: page, pageSize, account, credential });
    if (!r.ok) return r;
    const rows = r.rows || [];
    allRows.push(...rows);
    if (rows.length < pageSize) break;
    page++;
  }
  return { ok: true, rows: allRows, total: allRows.length };
}

module.exports = { query, create, update, del, queryAll, buildAuth };
