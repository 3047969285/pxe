#!/usr/bin/env node
// =====================================================
// 培小e —— 唯一入口：意图识别 + 路由分发
//
// 三大模块（相互独立）：
//   1. 数据维护  data_maint.js  Excel→JSON→API 交互式入库/修改/删除
//   2. 建议生成  ai_advisor.js  规则引擎自动分析产出一训建议名单（可存库归档）
//   3. 展示看板  html_viewer.js 查询API生成固模块HTML页面
//
// 用法：
//   node index.js 维护 [Excel路径]    交互式数据维护（提示输入账号密码）
//   node index.js 导入 <Excel> --table <表> [--account .. --credential ..]   直接入库
//   node index.js 建议 [--year 2026] [--store] [--account .. --credential ..]  生成培训建议
//   node index.js 看板 [--account .. --credential ..]   生成HTML展示页面
//   node index.js 导出 <条件> [--table ..]   导出Excel（框架）
//   node index.js 模板 [leader|plan|quota|record]   生成录入模板（框架）
//   node index.js 查询 <条件>   查数据（提示输入账号密码）
//   node index.js --auto        cron: 扫描autoInbox落库
//   node index.js --help
//
// 身份认证：
//   默认使用 config.js 管理员凭据（全量）
//   交互命令会提示用户输入 账号(姓名) + 凭证(身份证后四位/管理员密码)
//   也可用 --account / --credential 参数传入
// =====================================================
const path = require('path');
const CFG = require('./config');
const api = require('./train_api');
const excelHelper = require('./excel_helper');
const dataMaint = require('./data_maint');
const advisor = require('./ai_advisor');
const viewer = require('./html_viewer');
const readline = require('readline/promises');

// ---------- 参数解析 ----------
function parseArgs(argv) {
  const args = argv.slice(2).map((s) => s.trim()).filter(Boolean);
  if (args.length === 0) return { text: '--help' };

  const opts = {};
  let isAuto = false;
  const tokens = [];

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--auto') { isAuto = true; continue; }
    if (a === '--account' && args[i + 1]) { opts.account = args[++i]; continue; }
    if (a === '--credential' && args[i + 1]) { opts.credential = args[++i]; continue; }
    if (a === '--table' && args[i + 1]) { opts.table = args[++i]; continue; }
    if (a === '--year' && args[i + 1]) { opts.year = args[++i]; continue; }
    if (a === '--store') { opts.store = true; continue; }
    if (a === '--publish') { opts.publish = true; continue; }
    tokens.push(a);
  }

  return { text: tokens[0] || '', rest: tokens.slice(1), isAuto, opts };
}

// ---------- 意图路由表 ----------
const INTENT_RULES = [
  { action: 'maint', keywords: ['维护', '数据维护', '入库', '录入', '批量'] },
  { action: 'import', keywords: ['导入'] },
  { action: 'advice', keywords: ['建议', '应训未训', '未达标', '缺口', '推荐参训', '应训'] },
  { action: 'dashboard', keywords: ['看板', '大屏', '展示', '页面', 'HTML'] },
  { action: 'template', keywords: ['模板', '空表'] },
  { action: 'export', keywords: ['导出'] },
  { action: 'query', keywords: ['查询', '查', '名单', '列表', '统计', '多少人', '谁'] },
];

function detectIntent(text, isAuto) {
  if (isAuto) return 'auto';
  for (const rule of INTENT_RULES) {
    if (rule.keywords.some((k) => text.includes(k))) return rule.action;
  }
  return 'query';
}

// ---------- 表名规范化：key（leader/plan/quota/record）↔ 全表名（pxe_xxx）----------
const TABLE_KEY_MAP = {
  leader: CFG.tables.leader,
  plan: CFG.tables.plan,
  quota: CFG.tables.quota,
  record: CFG.tables.record,
};

function normalizeTable(t) {
  if (!t) return null;
  const key = String(t).toLowerCase();
  if (TABLE_KEY_MAP[key]) return TABLE_KEY_MAP[key]; // key → 全表名
  if (Object.values(TABLE_KEY_MAP).includes(t)) return t; // 已是全表名
  return null; // 未知
}

// ---------- 交互输入账号密码 ----------
async function askCredentials({ account, credential } = {}) {
  if (account && credential) return { account, credential };
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const acc = account || await rl.question('请输入账号（姓名）: ');
    const cred = credential || await rl.question('请输入凭证（身份证后四位/管理员密码）: ');
    return { account: acc.trim(), credential: cred.trim() };
  } finally {
    rl.close();
  }
}

// =====================================================
// 动作实现
// =====================================================

// -- 数据维护（交互式）--
async function runMaint(restText, opts) {
  const filePath = restText[0] || null;
  if (filePath) {
    console.log(`[培小e] 指定文件: ${filePath}`);
  }
  // 从 CLI 参数提取预认证信息（若提供则跳过交互式凭证输入）
  const preAuth = (opts.account && opts.credential) ? { account: opts.account, credential: opts.credential } : null;
  const result = await dataMaint.interactiveMaintenance(filePath, preAuth);
  return result;
}

// -- 直接导入（Execl→接口）--
async function runImport(restText, opts) {
  const filePath = restText[0];
  if (!filePath) {
    console.error('[培小e] 请指定 Excel 文件路径');
    console.log('  示例: node index.js 导入 ./黄岛培训.xlsx --table record');
    return;
  }
  const auth = await askCredentials(opts);
  const tableName = normalizeTable(opts.table) || dataMaint.autoDetectTable(filePath);
  if (!tableName) {
    console.error('[培小e] 无法自动识别表名，请用 --table 指定（leader/plan/quota/record）');
    return;
  }
  console.log(`[培小e] 目标表: ${tableName}`);
  await dataMaint.importDirect(filePath, tableName, auth.account, auth.credential);
}

// -- 培训建议（规则引擎）--
async function runAdvice(restText, opts) {
  const auth = await askCredentials(opts);
  const year = opts.year ? Number(opts.year) : new Date().getFullYear();

  console.log('[培小e] 开始生成培训建议（规则引擎）...');
  const result = await advisor.generateAdvice({
    account: auth.account,
    credential: auth.credential,
    year,
  });

  if (!result.ok) {
    console.error(`[培小e] 建议生成失败: ${result.error}`);
    return;
  }
  const advice = result.data;

  // 生成 HTML 展示
  const htmlFile = await advisor.buildAdviceHtml(advice, auth);
  console.log(`\n[培小e] 建议名单已生成: ${htmlFile}`);

  // 存库（可选 --store，单独方式归档）
  if (opts.store || opts.publish) {
    const archive = advisor.persistAdvice(advice);
    console.log('[培小e] 建议已按独立方式存库归档');
  }

  // 概要
  console.log(`\n📌 建议概要（年度 ${year}）:`);
  for (const p of advice.plans) {
    const cls = p.className || p.planId;
    const hi = p.advice.filter(a => a.priority === '高').length;
    console.log(`   ${cls}: 建议 ${p.suggestCount} 人（高优先 ${hi} 人，缺口 ${p.gap}）`);
  }
}

// -- 展示看板（HTML 固化模块）--
async function runDashboard(restText, opts, text) {
  const auth = await askCredentials(opts);
  console.log(`[培小e] 查询数据生成 HTML 看板...`);

  if (restText[0] === '建议' || text.includes('建议')) {
    // 带建议数据的看板
    const adviceResult = await advisor.generateAdvice({
      account: auth.account,
      credential: auth.credential,
      year: opts.year ? Number(opts.year) : new Date().getFullYear(),
    });
    if (!adviceResult.ok) {
      console.error(`[培小e] 建议生成失败: ${adviceResult.error}`);
      return;
    }
    return await renderAndSave(adviceResult.data, auth);
  }

  // 普通看板：直接查四表
  const html = await viewer.buildViewer(auth.account, auth.credential);
  const outDir = CFG.outDir;
  const fs = require('fs');
  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, `培小e看板_${today()}.html`);
  fs.writeFileSync(file, html, 'utf-8');
  console.log(`[培小e] 看板已生成: ${file}`);
}

async function renderAndSave(adviceData, auth) {
  const html = await viewer.renderAdvice(adviceData, auth);
  const fs = require('fs');
  fs.mkdirSync(CFG.outDir, { recursive: true });
  const file = path.join(CFG.outDir, `培小e看板_${today()}.html`);
  fs.writeFileSync(file, html, 'utf-8');
  console.log(`[培小e] 看板（含建议）已生成: ${file}`);
}

function today() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}`;
}

// -- 查询 --（交互式）
async function runQuery(restText, opts, text) {
  const auth = await askCredentials(opts);
  console.log(`[培小e] 执行查询: ${text}`);
  console.log(`  账号: ${auth.account}`);

  // 选择查询表（关键字猜测）
  const table = guessTable(text, opts.table);
  console.log(`  查询表: ${table}`);

  const filters = buildFilters(text);
  const res = await api.queryAll(table, filters, auth.account, auth.credential);
  if (!res.ok) {
    console.error(`[培小e] 查询失败: ${res.message || res.error}`);
    return;
  }
  const rows = res.rows || [];
  console.log(`[培小e] 查到 ${rows.length} 条记录\n`);

  // 打印前 50 条
  const cols = Object.keys(rows[0] || {});
  if (cols.length === 0) {
    console.log('  (无结果)');
    return;
  }
  const headers = cols.join('\t');
  console.log(headers);
  console.log('-'.repeat(Math.min(80, headers.length)));
  rows.slice(0, 50).forEach(r => {
    console.log(cols.map(c => r[c] ?? '').join('\t'));
  });
  if (rows.length > 50) console.log(`  ... 还有 ${rows.length - 50} 条`);
}

function guessTable(text, tableOpt) {
  const t = (tableOpt || '').toLowerCase();
  if (t) {
    const map = { leader: CFG.tables.leader, plan: CFG.tables.plan, quota: CFG.tables.quota, record: CFG.tables.record };
    if (map[t]) return map[t];
    if (Object.values(map).includes(t)) return t;
  }
  if (/人员|干部|领导|在册/.test(text)) return CFG.tables.leader;
  if (/计划|培训计划|班次|培训班/.test(text)) return CFG.tables.plan;
  if (/名额|分配|配额/.test(text)) return CFG.tables.quota;
  return CFG.tables.record;
}

function buildFilters(text) {
  const filters = [];
  const yearMatch = text.match(/(20\d{2})年/);
  if (yearMatch) {
    filters.push({ field: 'plan_year', operator: 'EQ', value: Number(yearMatch[1]) });
  }
  return filters;
}

// -- 导出 --（框架）
async function runExport(restText, opts, text) {
  const auth = await askCredentials(opts);
  const table = normalizeTable(opts.table) || guessTable(text, opts.table);
  const res = await api.queryAll(table, buildFilters(text), auth.account, auth.credential);
  if (!res.ok) {
    console.error(`[培小e] 查询失败: ${res.message || res.error}`);
    return;
  }
  const filename = excelHelper.exportToExcel(res.rows || [], table, `培小e导出_${today()}.xlsx`);
  console.log(`[培小e] 导出完成: ${filename}`);
}

// -- 模板 --（框架）
async function runTemplate(restText, opts) {
  const tname = restText[0] || opts.table || 'record';
  const tableFull = normalizeTable(tname) || tname;
  const filename = excelHelper.makeTemplate(tableFull);
  console.log(`[培小e] 录入模板已生成: ${filename}`);
}

// -- 自动流程 --
async function runAuto() {
  console.log('[培小e] 自动流程启动...');
  const inbox = CFG.autoInbox;
  const files = excelHelper.listInbox(inbox);
  if (files.length === 0) {
    console.log(`[培小e] 输入目录无新文件: ${inbox}`);
    return;
  }
  for (const f of files) {
    console.log(`[培小e] 待入库: ${f}`);
    const table = dataMaint.autoDetectTable(f);
    if (!table) { console.log(`  ⚠ 无法识别表名，已跳过`); continue; }
    await dataMaint.importDirect(f, table, CFG.admin.account, CFG.admin.credential);
  }
  console.log('[培小e] 自动流程完成');
}

// ---------- 帮助 ----------
function showHelp() {
  console.log(`培小e —— 培训数据智能助手

三大独立模块：
  1. 数据维护：Excel→JSON→接口 交互式入库/改/删（提示输入账号密码）
  2. 建议生成：规则引擎自动分析，产出应训未训建议名单（可独立存库归档）
  3. 展示看板：查询接口生成固化模块 HTML 页面

用法：
  维护 [Excel路径]              交互式数据维护（导入/修改/删除）
  导入 <Excel> --table <表>      直接导入指定表（leader/plan/quota/record）
  建议 [--year 2026] [--store] 生成培训建议名单（--store 归档存库）
  看板                          生成 HTML 数据看板页面
  看板 建议 --year 2026         生成含建议数据的看板
  查询 <条件>                   查数据并回显（自动识别表）
  导出 <条件> --table <表>      导出 Excel
  模板 [表]                     生成录入模板
  --auto                        cron: 扫描输入目录自动入库

身份参数（可选，缺省交互提示）：
  --account <姓名>        账号
  --credential <后四位>   凭证（身份证后四位/管理员密码）
  --table <表>            目标表
  --year <年份>           建议年度

示例：
  node index.js 维护
  node index.js 导入 ./黄岛7月培训.xlsx --table record
  node index.js 建议 --year 2026 --store
  node index.js 看板 建议 --year 2026`);
}

// ---------- 主流程 ----------
async function main() {
  const { text, rest, isAuto, opts } = parseArgs(process.argv);

  if (text === '--help' || text === '-h') {
    showHelp();
    return;
  }

  const action = detectIntent(text, isAuto);
  const actions = {
    auto: () => runAuto(),
    maint: () => runMaint(rest, opts),
    import: () => runImport(rest, opts),
    advice: () => runAdvice(rest, opts),
    dashboard: () => runDashboard(rest, opts, text),
    template: () => runTemplate(rest, opts),
    export: () => runExport(rest, opts, text),
    query: () => runQuery(rest, opts, text),
  };

  try {
    await actions[action]();
  } catch (e) {
    console.error('[培小e] 执行出错:', e.message);
    console.error(e.stack);
    process.exitCode = 1;
  }
}

main();
