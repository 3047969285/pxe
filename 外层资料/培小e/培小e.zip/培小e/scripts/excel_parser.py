#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
excel_parser.py —— 培小e Excel 解析桥接脚本
用 openpyxl 读取 Excel 文件，将中文表头映射到后端 API 字段白名单，
输出 JSON 到 stdout，供 Node.js 主流程调用。

用法：
  python excel_parser.py <文件路径> <表名>              # 解析数据行
  python excel_parser.py <文件路径> <表名> --headers     # 只输出表头映射
  python excel_parser.py <文件路径> <表名> --info        # 输出文件概要信息

返回格式（stdout）：
  {"ok":true, "rows":[...], "fieldMap":{...}, "totalRows":N}
  或
  {"ok":false, "error":"..."}

四张表的字段映射（中文→英文）见 FIELD_MAPS 字典。
若需校准中文表头，修改 FIELD_MAPS 中的 key 即可。
"""

import sys
import json
import os
import tempfile
from openpyxl import load_workbook, Workbook

# =========================================
# 四张表的字段映射：Excel 中文表头 → 后端字段名
# 识别策略：优先精确匹配，再用"模糊包含"容错
# 部署后拿到真实 Excel 模板再校准
# =========================================
FIELD_MAPS = {
    "pxe_leader_info": {
        "序号": "seq_no",
        "地区": "region_name",
        "单位": "unit_name",
        "姓名": "emp_name",
        "编号": "emp_id",
        "身份证号": "id_card",
        "身份证": "id_card",
        "性别": "gender",
        "年龄": "age",
        "辅助日期": "assist_date",
        "角色": "b_role",
        "干部层级": "cadre_level",
        "职级": "staff_grade",
        "是否党委": "is_party_sec",
        "2026已训": "trained_2026",
        "已训": "trained_2026",
        "总学时": "total_hours",
        "是否生产骨干": "is_prod_head",
        "生产骨干": "is_prod_head",
        "备注": "remark",
    },
    "pxe_training_plan": {
        "批次": "batch_id",
        "计划年份": "plan_year",
        "年份": "plan_year",
        "序号": "seq_no",
        "培训班名称": "class_name",
        "培训班": "class_name",
        "班次名称": "class_name",
        "期次": "session_no",
        "培训周期": "train_period",
        "周期": "train_period",
        "开始日期": "start_date",
        "结束日期": "end_date",
        "培训地点": "train_place",
        "地点": "train_place",
        "计划人数": "plan_count",
        "培训对象": "target_group",
        "对象": "target_group",
        "规则说明": "rule_desc",
        "规则键": "rule_key",
        "匹配规则": "matching_rules",
        "备注": "remark",
    },
    "pxe_quota_alloc": {
        "计划ID": "plan_id",
        "培训计划ID": "plan_id",
        "单位名称": "unit_name",
        "单位": "unit_name",
        "名额数量": "quota_count",
        "名额": "quota_count",
        "备注": "remark",
    },
    "pxe_train_record": {
        "计划ID": "plan_id",
        "人员编号": "emp_id",
        "编号": "emp_id",
        "姓名": "emp_name",
        "计划年份": "plan_year",
        "年份": "plan_year",
        "培训班名称": "class_name",
        "培训班": "class_name",
        "班次名称": "class_name",
        "培训类别": "class_type",
        "类别": "class_type",
        "期次": "session_no",
        "开始日期": "start_date",
        "结束日期": "end_date",
        "学时": "hours",
        "参训时单位": "unit_at_time",
        "参训单位": "unit_at_time",
        "数据来源": "data_source",
        "来源": "data_source",
        "备注": "remark",
    },
}

# 白名单字段（后端可写字段，做过滤用）
WHITELIST_FIELDS = {
    "pxe_leader_info": [
        "seq_no", "region_name", "unit_name", "emp_name", "emp_id",
        "id_card", "gender", "age", "assist_date", "b_role", "cadre_level",
        "staff_grade", "is_party_sec", "trained_2026", "total_hours",
        "is_prod_head", "remark",
    ],
    "pxe_training_plan": [
        "batch_id", "plan_year", "seq_no", "class_name", "session_no",
        "train_period", "start_date", "end_date", "train_place", "plan_count",
        "target_group", "rule_desc", "rule_key", "matching_rules", "remark",
    ],
    "pxe_quota_alloc": ["plan_id", "unit_name", "quota_count", "remark"],
    "pxe_train_record": [
        "plan_id", "emp_id", "emp_name", "plan_year", "class_name",
        "class_type", "session_no", "start_date", "end_date", "hours",
        "unit_at_time", "data_source", "remark",
    ],
}

# 需要转数字的字段
NUMERIC_FIELDS = {
    "plan_year", "seq_no", "session_no", "plan_count", "quota_count",
    "hours", "age", "total_hours",
}

# 需要传 JSON 对象的字段
JSON_FIELDS = {"matching_rules"}


def normalize_value(field, value):
    """字段值类型规范化"""
    if value is None:
        return None
    s = str(value).strip()
    if s == "" or s == "None":
        return None
    if field in NUMERIC_FIELDS:
        try:
            # 去除非数字字符（保留 . 和 -）
            clean = "".join(c for c in s if c.isdigit() or c in ".-")
            if "." in clean:
                return float(clean)
            return int(clean)
        except (ValueError, TypeError):
            return s
    if field in JSON_FIELDS:
        try:
            return json.loads(s)
        except (json.JSONDecodeError, TypeError):
            return s
    return s


def build_field_map(headers, table_name):
    """根据 Excel 表头构建 中文列名→后端字段 的映射字典"""
    mapping = FIELD_MAPS.get(table_name, {})
    result = {}
    unmatched = []
    for h in headers:
        h_stripped = h.strip()
        if h_stripped in mapping:
            result[h_stripped] = mapping[h_stripped]
        else:
            # 模糊匹配：包含关系
            found = False
            for cn, en in mapping.items():
                if cn in h_stripped or h_stripped in cn:
                    result[h_stripped] = en
                    found = True
                    break
            if not found:
                unmatched.append(h_stripped)
    return result, unmatched


def parse_excel(filepath, table_name, mode="data"):
    """主解析函数"""
    if not os.path.exists(filepath):
        return {"ok": False, "error": f"文件不存在: {filepath}"}
    if table_name not in FIELD_MAPS:
        return {
            "ok": False,
            "error": f"未知表名: {table_name}，可用: {list(FIELD_MAPS.keys())}",
        }

    try:
        wb = load_workbook(filepath, read_only=True, data_only=True)
    except Exception as e:
        return {"ok": False, "error": f"无法打开 Excel: {str(e)}"}

    ws = wb.active
    if ws is None:
        wb.close()
        return {"ok": False, "error": "Excel 中没有工作表"}

    rows_iter = ws.iter_rows(values_only=True)
    try:
        raw_headers = [str(c or "").strip() for c in next(rows_iter)]
    except StopIteration:
        wb.close()
        return {"ok": False, "error": "Excel 是空表"}

    # 构建字段映射
    field_map, unmatched = build_field_map(raw_headers, table_name)
    whitelist = WHITELIST_FIELDS.get(table_name, [])

    if mode == "headers":
        wb.close()
        return {
            "ok": True,
            "mode": "headers",
            "table": table_name,
            "rawHeaders": raw_headers,
            "fieldMap": field_map,
            "unmatched": unmatched,
            "totalRows": 0,
        }

    # 解析数据行
    rows = []
    errors = []
    row_idx = 1  # 从第2行开始（第1行是表头）
    for row in rows_iter:
        row_idx += 1
        # 跳过全空行
        if all(c is None or str(c).strip() == "" for c in row):
            continue
        obj = {}
        skipped_headers = []
        for i, val in enumerate(row):
            if i >= len(raw_headers):
                continue
            header = raw_headers[i]
            if header not in field_map:
                continue
            field = field_map[header]
            if field not in whitelist:
                skipped_headers.append(header)
                continue
            obj[field] = normalize_value(field, val)
        if obj:
            rows.append(obj)
        if skipped_headers:
            errors.append(f"第{row_idx}行: 跳过了非白名单字段 {skipped_headers}")

    wb.close()

    # field_map 反向索引用于输出
    output_map = {v: k for k, v in field_map.items()}

    return {
        "ok": True,
        "mode": "data",
        "table": table_name,
        "rows": rows,
        "fieldMap": output_map,
        "unmatched": unmatched,
        "totalRows": len(rows),
        "warnings": errors if errors else None,
    }


# =========================================
# 生成模板列表
# =========================================
def build_header_row(table_name):
    """根据字段映射生成模板表格头（英文字段→中文示例名）"""
    mapping = FIELD_MAPS.get(table_name, {})
    if not mapping:
        return []
    # 取映射中每个英文字段的一个中文表头（优先短名）
    en_to_cn = {}
    for cn, en in mapping.items():
        if en not in en_to_cn or len(cn) < len(en_to_cn[en]):
            en_to_cn[en] = cn
    return [en_to_cn[en] for en in en_to_cn]


def write_excel(filepath, table_name, rows):
    """将数据写入 Excel，返回 {ok, file, totalRows}"""
    if not table_name:
        return {"ok": False, "error": "未指定表名"}
    mapping = FIELD_MAPS.get(table_name, {})
    whitelist = WHITELIST_FIELDS.get(table_name, [])

    # 输出列顺序：按白名单，取映射优先；无映射的直接用英文名
    en_to_cn = {}
    for cn, en in mapping.items():
        if en not in en_to_cn or len(cn) < len(en_to_cn[en]):
            en_to_cn[en] = cn
    columns = [c for c in whitelist]  # 白名单顺序即为列顺序
    headers = [en_to_cn.get(c, c) for c in columns]

    def cell_value(v):
        # openpyxl 只接受标量；dict/list（如 matching_rules JSON 对象）须序列化成字符串
        if isinstance(v, (dict, list, tuple, bool, int, float, str)) or v is None:
            if isinstance(v, (dict, list, tuple)):
                return json.dumps(v, ensure_ascii=False)
            return v
        return str(v)

    try:
        wb = Workbook()
        ws = wb.active
        ws.title = table_name
        ws.append(headers)
        for r in rows:
            ws.append([cell_value(r.get(c, "")) for c in columns])
        # 简单列宽
        for idx, _ in enumerate(columns, 1):
            ws.column_dimensions[ws.cell(row=1, column=idx).column_letter].width = 16
        wb.save(filepath)
    except Exception as e:
        return {"ok": False, "error": f"写入 Excel 失败: {str(e)}"}

    return {"ok": True, "file": filepath, "totalRows": len(rows), "columns": columns}


def write_template(filepath, table_name):
    """生成某表的空录入模板（表头+示例行）"""
    mapping = FIELD_MAPS.get(table_name, {})
    whitelist = WHITELIST_FIELDS.get(table_name, [])
    en_to_cn = {}
    for cn, en in mapping.items():
        if en not in en_to_cn or len(cn) < len(en_to_cn[en]):
            en_to_cn[en] = cn
    columns = [c for c in whitelist]
    headers = [en_to_cn.get(c, c) for c in columns]

    try:
        wb = Workbook()
        ws = wb.active
        ws.title = table_name
        ws.append(headers)
        ws.append(["" for _ in columns])
        for idx, _ in enumerate(columns, 1):
            ws.column_dimensions[ws.cell(row=1, column=idx).column_letter].width = 16
        wb.save(filepath)
    except Exception as e:
        return {"ok": False, "error": f"生成模板失败: {str(e)}"}

    return {"ok": True, "file": filepath, "columns": columns}


def main():
    global INDEX
    args = sys.argv[1:]

    # 新参数约定：--export <数据json> <输出xlsx> <表名>  或  --template <输出xlsx> <表名>
    if args and args[0] in ("--export", "--template"):
        mode = args[0]
        if mode == "--export":
            if len(args) < 4:
                print(json.dumps({"ok": False, "error": "用法: python excel_parser.py --export <数据json> <输出xlsx> <表名>"}))
                sys.exit(1)
            data_path, out_path, table_name = args[1], args[2], args[3]
            try:
                with open(data_path, "r", encoding="utf-8") as f:
                    rows = json.load(f)
            except Exception as e:
                print(json.dumps({"ok": False, "error": f"读取数据 JSON 失败: {str(e)}"}))
                sys.exit(1)
            result = write_excel(out_path, table_name, rows)
        else:
            if len(args) < 3:
                print(json.dumps({"ok": False, "error": "用法: python excel_parser.py --template <输出xlsx> <表名>"}))
                sys.exit(1)
            out_path, table_name = args[1], args[2]
            result = write_template(out_path, table_name)

        print(json.dumps(result, ensure_ascii=False, default=str))
        if not result.get("ok"):
            sys.exit(1)
        return

    if len(args) < 2:
        print(json.dumps({"ok": False, "error": "用法: python excel_parser.py <文件路径> <表名> [--headers|--info]"}))
        sys.exit(1)

    filepath = args[0]
    table_name = args[1]
    mode = "data"
    if len(args) > 2:
        flag = args[2].strip().lower()
        if flag in ("--headers", "--header"):
            mode = "headers"
        elif flag == "--info":
            mode = "info"

    result = parse_excel(filepath, table_name, mode)
    print(json.dumps(result, ensure_ascii=False, default=str))

    if not result.get("ok"):
        sys.exit(1)


if __name__ == "__main__":
    main()
