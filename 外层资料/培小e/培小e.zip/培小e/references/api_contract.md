# 培小e 培训数据接口契约

> 本文档依据「培小e培训数据接口调用说明.docx」编写，是 Skill 与后端之间的完整接口约定。
> 后端尚未部署（当前示例地址 localhost:7529），部署后修改 config.js 中的 baseUrl 即可对接。

---

## 1. 接口概览

接口统一 POST，Content-Type: `application/json`。Base URL: `{baseUrl}/api/HuangDao/training`

| 操作 | 完整路径 | 作用 |
|---|---|---|
| 查询 | `POST /api/HuangDao/training/query` | 按身份和筛选条件分页查询 |
| 新增或更新 | `POST /api/HuangDao/training/create` | 单条/批量维护，业务唯一键冲突时更新(UPSERT) |
| 修改 | `POST /api/HuangDao/training/update` | 按主键精确定位并修改指定字段 |
| 软删除 | `POST /api/HuangDao/training/delete` | 标记 del_flag=2，不物理删除 |

所有接口均在同一个 Base URL 下，通过路径区分操作。部署后将示例地址 `http://localhost:7529` 替换为实际服务地址和端口。

---

## 2. 认证（每次请求必须携带）

两处认证用途不同，调用时必须同时提供。

| 位置 | 字段 | 填写方式 |
|---|---|---|
| HTTP Header | Authorization | 服务端 `app.api-secret` 配置的值；直接填写，不加 Bearer 前缀 |
| JSON Body | account | 普通用户填人员姓名；管理层填 `admin`（不区分大小写） |
| JSON Body | credential | 普通用户填身份证后四位；管理层填管理员密码 |

- 普通用户身份通过人员表姓名+身份证后四位校验，必须匹配到唯一有效人员记录
- 姓名重复或身份不匹配时接口拒绝请求
- **Authorization 密钥和管理员密码属于敏感凭据**，由 Skill 端 config.js 持有，不放入日志或公开内容
- 普通用户运行时通过 `--account`/`--credential` 参数传入，不入配置文件

---

## 3. 通用请求参数

以下参数适用于所有 4 个接口（标注"部分适用"的只用于特定操作）。

| 参数 | 适用接口 | 说明 |
|---|---|---|
| account | 全部 | **必填**。普通用户填姓名，管理员填 admin |
| credential | 全部 | **必填**。普通用户填身份证后四位，管理员填管理员密码 |
| table | 全部 | **必填**。数据库表名枚举：`pxe_leader_info` / `pxe_training_plan` / `pxe_quota_alloc` / `pxe_train_record` |
| filters | query/update/delete | 筛选条件数组（数组每个元素为条件对象）；多个条件按 AND 组合；update/delete 必须包含主键 EQ |
| columns | query 部分 | 指定返回字段；不传时使用该表默认字段 |
| pageNum | query | 页码从 1 开始，默认 1 |
| pageSize | query | 每页条数，默认 20，最大 500 |
| orderBy | query | 排序字段（须属该表白名单），默认按主键 |
| orderDirection | query | `ASC` 或 `DESC`，默认 ASC |
| values | create/update | 单条数据对象；create 时必填 fields；update 时只放要修改的字段 |
| rows | create | 批量数据数组，最多 500 条；每行字段集合须一致；不可与 values 同时传 |

字段名使用数据库风格（如 `emp_name`、`plan_year`）。服务端只接受当前表白名单中的字段，不接受 SQL 语句或任意动态字段。

---

## 4. 筛选条件写法（filters 数组）

每个条件对象格式：

```json
{ "field": "plan_year", "operator": "EQ", "value": 2026 }
```

| 类别 | operator | value 说明 |
|---|---|---|
| 比较 | EQ、NE、GT、GE、LT、LE | 单个值，如 2026 |
| 模糊 | LIKE、NOT_LIKE | 字符串，如 "培训"（按包含关系匹配） |
| 集合 | IN、NOT_IN | 数组，如 [2025, 2026] |
| 区间 | BETWEEN | 双元素数组，如 ["2026-01-01", "2026-12-31"] |
| 空值 | IS_NULL、IS_NOT_NULL | 不传 value |

- LIKE/NOT_LIKE：value 为"培训"，匹配包含"培训"的记录
- IN/NOT_IN：value 必须是数组
- BETWEEN：value 必须是双元素数组
- IS_NULL/IS_NOT_NULL：不传 value
- 单次查询最多 50 个筛选条件

---

## 5. 四张表与业务字段

### 5.1 表概览

| 数据表 | 表名 | 主键 | 新增必填 | 业务匹配键 |
|---|---|---|---|---|
| 人员信息 | pxe_leader_info | leader_id | region_name, unit_name, emp_name, emp_id | emp_id |
| 培训计划 | pxe_training_plan | plan_id | plan_year, class_name, session_no | plan_year+class_name+session_no |
| 单位名额 | pxe_quota_alloc | quota_id | plan_id, unit_name | plan_id+unit_name |
| 培训记录 | pxe_train_record | record_id | emp_id, emp_name, plan_year, class_name, session_no | emp_id+plan_year+class_name+session_no |

- guid 由服务端生成；主键、删除标记(del_flag)、创建/更新时间由服务端管理，不作为业务字段提交
- 可写字段以服务端白名单为准；普通用户可写范围更窄（见第 7 节）

### 5.2 各表白名单字段

**pxe_leader_info（人员信息）**
`seq_no`、`region_name`、`unit_name`、`emp_name`、`emp_id`、`id_card`、`gender`、`age`、`assist_date`、`b_role`、`cadre_level`、`staff_grade`、`is_party_sec`、`trained_2026`、`total_hours`、`is_prod_head`、`remark`

**pxe_training_plan（培训计划）**
`batch_id`、`plan_year`、`seq_no`、`class_name`、`session_no`、`train_period`、`start_date`、`end_date`、`train_place`、`plan_count`、`target_group`、`rule_desc`、`rule_key`、`matching_rules`、`remark`

`matching_rules` 可传 JSON 对象，服务端序列化保存。
该接口只保存计划和规则，不自动排期或计算参训人员。

**pxe_quota_alloc（单位名额分配）**
`plan_id`、`unit_name`、`quota_count`、`remark`

`plan_id` 须填数据库中实际存在的培训计划主键。

**pxe_train_record（培训记录）**
`plan_id`、`emp_id`、`emp_name`、`plan_year`、`class_name`、`class_type`、`session_no`、`start_date`、`end_date`、`hours`、`unit_at_time`、`data_source`、`remark`

普通用户新增本人记录时，`emp_id` 和 `emp_name` 由服务端自动绑定，不能给其他人新增记录。

### 5.3 地区权限说明

- 当前后端实现按**单位(unit_name)**控制数据范围：普通用户只能查看本人记录+本单位名额+分配给自己单位的计划
- **TODO**：若需按地区(region_name)开放（如"黄岛用户看黄岛全区数据"），需后端扩展该规则（当前代码尚未提供该功能）

---

## 6. 各接口详情

### 6.1 查询（/query）

- 默认只返回 `del_flag=0` 的有效记录
- `total` 是当前身份范围和筛选条件下的总数（非当前页条数）
- 需要读取全部结果时逐页请求；pageSize 最大 500

**管理员查询示例：**
```json
{
  "account": "admin",
  "credential": "<管理员密码>",
  "table": "pxe_leader_info",
  "filters": [
    { "field": "region_name", "operator": "EQ", "value": "示例地区" }
  ],
  "columns": ["leader_id", "region_name", "unit_name", "emp_name", "emp_id"],
  "pageNum": 1,
  "pageSize": 20,
  "orderBy": "emp_name",
  "orderDirection": "ASC"
}
```

**普通用户查询示例：**
```json
{
  "account": "<本人姓名>",
  "credential": "<身份证后四位>",
  "table": "pxe_train_record",
  "filters": [
    { "field": "plan_year", "operator": "EQ", "value": 2026 }
  ],
  "pageNum": 1,
  "pageSize": 20
}
```

**成功响应：**
```json
{
  "code": 0,
  "data": {
    "rows": [],
    "total": 37,
    "pageNum": 1,
    "pageSize": 20
  },
  "message": "ok"
}
```

- 人员表默认字段不包含 `id_card`；管理员把 `id_card` 放入 `columns` 才返回完整值，普通用户请求该字段看到脱敏值

### 6.2 新增或更新（/create）

- 支持 `values`（单条）或 `rows`（批量），不能同时传两者，不接受 filters
- 执行 **UPSERT**：首次出现业务唯一键时新增，已存在时更新本次提交的字段
- 批次内重复业务键被拒绝；每批最多 500 行，每行字段集合须一致
- `matching_rules` 传 JSON 对象

**人员资料示例（管理员）：**
```json
{
  "account": "admin",
  "credential": "<管理员密码>",
  "table": "pxe_leader_info",
  "values": {
    "region_name": "示例地区",
    "unit_name": "示例单位",
    "emp_name": "示例人员",
    "emp_id": "EMP_EXAMPLE_001",
    "id_card": "<身份证号>",
    "gender": "男",
    "remark": "示例"
  }
}
```

**培训计划批量示例（管理员）：**
```json
{
  "account": "admin",
  "credential": "<管理员密码>",
  "table": "pxe_training_plan",
  "rows": [
    {
      "plan_year": 2026,
      "class_name": "示例培训班A",
      "session_no": 1,
      "start_date": "2026-11-10",
      "end_date": "2026-11-12",
      "train_place": "示例地点",
      "plan_count": 30,
      "target_group": "示例对象",
      "rule_desc": "示例规则",
      "matching_rules": { "targetGroup": "示例对象" }
    }
  ]
}
```

**本人培训记录示例（普通用户）：**
```json
{
  "account": "<本人姓名>",
  "credential": "<身份证后四位>",
  "table": "pxe_train_record",
  "values": {
    "plan_id": 123,
    "plan_year": 2026,
    "class_name": "示例培训班",
    "class_type": "示例类别",
    "session_no": 1,
    "start_date": "2026-11-10",
    "end_date": "2026-11-12",
    "hours": 16,
    "unit_at_time": "示例单位",
    "data_source": "Excel",
    "remark": "示例"
  }
}
```

**成功响应：**
```json
{
  "code": 0,
  "data": {
    "table": "pxe_train_record",
    "action": "UPSERT",
    "submittedRows": 1,
    "affectedRows": 1,
    "success": true
  },
  "message": "ok"
}
```

### 6.3 修改（/update）

- 只作用于有效数据（del_flag=0）
- `filters` 必须包含当前表主键的 EQ 条件，所有筛选条件只支持 EQ
- `values` 只放需要修改的字段；若某字段传 null 可能把数据库该字段清空

```json
{
  "account": "<本人姓名>",
  "credential": "<身份证后四位>",
  "table": "pxe_train_record",
  "filters": [
    { "field": "record_id", "operator": "EQ", "value": 456 }
  ],
  "values": {
    "hours": 20,
    "remark": "修改后的备注"
  }
}
```

### 6.4 软删除（/delete）

- 将 `del_flag` 设为 2，不物理删除
- 不要传 `values` 或 `del_flag`

```json
{
  "account": "<本人姓名>",
  "credential": "<身份证后四位>",
  "table": "pxe_train_record",
  "filters": [
    { "field": "record_id", "operator": "EQ", "value": 456 }
  ]
}
```

---

## 7. 权限范围

| 身份 | 查询范围 | 可维护范围 |
|---|---|---|
| 管理员(admin) | 四张表全量，可按条件筛选 | 四张表白名单允许的业务字段 |
| 普通用户(本人) | 本人资料和记录；本人单位名额；分配给自己单位的计划 | 本人资料的非身份字段；本人培训记录 |

- 普通用户不能创建人员、培训计划或名额分配
- 当前实现按单位控制名额和计划可见性，不按整个地区开放（地区开放规则待后端扩展）

---

## 8. 响应与错误码

成功：`code=0`，`message="ok"`；查询数据在 `data.rows`；写入结果在 `data` 中。

| 情况 | 返回 | 检查方向 |
|---|---|---|
| Authorization 缺失或不匹配 | HTTP 401 | 核对 app.api-secret；Authorization 不加 Bearer |
| 身份校验失败或无权限 | 40100 / 40101 | 核对姓名、身份证后四位或管理员身份 |
| 参数不符合规则 | 40000 | 核对表名、字段白名单、必填项、运算符和主键条件 |
| 普通用户越权 | 40101 | 确认目标记录属于本人 |

---

## 9. Skill 端调用流程建议

1. **Excel 解析**：识别工作表和表头，将中文列名映射到当前表白名单字段，校验必填和数据类型
2. **判存**：需判断数据是否存在时，先按主键或业务键调 query，处理分页
3. **写入**：合法记录按 table 分组，用 rows 批量调 create（接口按业务唯一键 UPSERT）
4. **修改/删除**：先确认主键，再调 update/delete（不拼接/执行原始 SQL）
5. **核对**：写后可再次分页查询核对；注意主从库复制延迟可能导致新写入暂不可见
6. **应训未训名单**：后端不计算调训缺口——由 Skill 拉取计划+记录，本地比对产出
