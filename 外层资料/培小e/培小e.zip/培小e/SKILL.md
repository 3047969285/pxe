---
author_name: 王英
category_id: 1
name: 培小e
summary: 培训数据智能助手：自然语言入库/查询/导出/大屏看板/建议名单
core_features: 自然语言增改数据入库、自然语言查库与Excel导出/模板、双业务库操作、多维度大屏看板(单位/层级/时间/班次)、应训未训建议名单、定时自动更新、地区数据范围控制
trigger_mode: 对话中提及培训数据、培训名单、培训大屏、培训看板、培训模板、导入培训Excel、出建议名单等需求时触发；也支持定时自动执行
use_scenarios: 月度/季度各单位领导培训Excel批量入库、省公司培训通知登记、查询某班次/某单位参训名单、生成培训数据大屏、导出培训明细Excel、生成应训未训建议名单
description: 培小e 是培训数据管理与分析智能体。三大独立模块：(1)【数据维护】交互式Excel转JSON录入后端数据库，支持导入/修改/删除，用户输入账号密码操作；(2)【AI建议生成】内置规则引擎自动分析培训计划、人员档案、已训记录，按层级/角色/名额等多维规则生成应训未训建议名单，支持独立存库归档；(3)【HTML展示看板】固化模块HTML页面（人员/计划/记录/名额/建议/统计7大Tab），查询接口填充占位符，无需服务器直接打开。另有真实Excel导出（剔除敏感字段）与录入模板生成。对接4个JSON接口（query/create/update/delete），内置身份认证与权限控制。
---

# 培小e · 培训数据管理与分析智能体

## 三大独立模块

### 模块一：数据维护（data_maint.js）

交互式 Excel → JSON → 后端接口入库/修改/删除，支持用户的自然语言操作。

**核心流程**：
- 用户说出/拖入 Excel 文件，按人员/计划/记录/名额自动识别表
- Python openpyxl 解析，中文表头自动映射后端字段，输出 JSON
- 每行逐一显示，用户确认后调用 create/update API
- 支持批量导入、修改、删除，用户交互式输入账号密码

**交互式维护命令**：
- `node index.js 维护` 或 `node index.js 维护 Excel路径`（拖拽路径自动去引号）
- 录入前预览前 3 行数据 + 确认提示
- `checkApiReady` 自动检测 baseUrl 是否被正确配置（localhost 时给出警告）

### 模块二：AI 建议生成（ai_advisor.js）

内置规则引擎自动分析培训计划、人员档案、已训记录，生成应训未训建议名单。

**R1-R5 规则引擎**：

| 规则 | 逻辑 | 说明 |
|---|---|---|
| R1 计划匹配 | 读 `matching_rules` JSON（`cadreLevel/role/prodHead`）或 `target_group` 关键词 | 计划匹配规则为空时自动跳过该计划（不产建议） |
| R2 已训排除 | 按人员参与同类培训的历史学时 ≥ 8h 剔除 | 避免重复培训 |
| R3 学时补充 | R2 剔除时已训 < 8h 者标记 "需补充" | 部分完成 |
| R4 配额限制 | 读 `pxe_quota_alloc` 每计划-单位名额上限，超额按优先级截断 | 名额约束 |
| R5 优先级评分 | 层级(35)+角色(25)+骨干(20)+未训(20)+学时空缺(5) → 100 满分 | 排序定先 |

**输出**：
- 控制台概要（每个计划：建议人数、高优先人数、缺口数）
- HTML 看板（含建议部门，与模块三共用）
- `--store` 时独立存库归档：JSON 全量 + CSV 台账追加（`{outDir}/_建议归档/`）

### 模块三：HTML 展示看板（html_viewer.js）

查询四张表数据，填充固化 HTML 模板，生成自包含页面。

**7 个固化模块**：

| Tab | 占位符 | 数据源 |
|---|---|---|
| 人员信息 | `{{PERSON_ROWS}}` | `pxe_leader_info` |
| 培训计划 | `{{PLAN_ROWS}}` | `pxe_training_plan` |
| 培训记录 | `{{RECORD_ROWS}}` | `pxe_train_record` |
| 单位名额 | `{{QUOTA_ROWS}}` | `pxe_quota_alloc` |
| 培训建议 | `{{ADVICE_CONTENT}}` | ai_advisor 产出 |
| 统计看板 | `{{STATS_BY_UNIT}}` | 前端聚合 |
| 数据导出 | `{{EXPORT_PLACEHOLDER}}` | 预留 |

- 纯原生 HTML+CSS+JS，无外部依赖，内网离线可用
- 运行一次即生成完整 HTML 文件，浏览器直接打开
- Tab 切换 + 表格搜索筛选
- 单表查询失败自动降级（Promise.allSettled），不影响其他 Tab
- API 返回数据经 HTML 转义，防止特殊字符破坏页面

## 关键脚本

| 脚本 | 职责 | 技术 |
|---|---|---|
| `index.js` | 唯一入口：意图识别 + 三大模块路由 | Node.js CLI |
| `train_api.js` | 后端 4 接口封装（query/create/update/delete），AbortController 超时 | Node.js fetch |
| `data_maint.js` | Excel→JSON→API 交互式维护（凭证优先级、数据预览确认） | Node.js + readline |
| `excel_parser.py` | Excel 解析 + 写入（openpyxl 桥接，兼读/写 xlsx，--export/--template） | Python openpyxl |
| `ai_advisor.js` | 规则引擎：R1-R5 自动产出建议名单（空规则跳过、CSV 转义） | Node.js 纯逻辑 |
| `html_viewer.js` | 固化模块 HTML 生成器（占位符替换+allSettled 降级+HTML 转义） | Node.js 模板引擎 |
| `excel_helper.js` | 导出 xlsx（经 Python 写入、剔除敏感字段 id_card）、生成模板、扫描目录 | Node.js + execFileSync |
| `config.js` | API 地址/凭据/表名映射/输出目录 | Node.js 配置 |

## 触发方式

- **自然语言**：`培小e 导入 ./黄岛7月培训.xlsx --table record`
- **交互式**：`培小e 维护`（提示输入账号密码）
- **建议生成**：`培小e 建议 --year 2026 --store`
- **看板生成**：`培小e 看板 建议 --year 2026`
- **导出**：`培小e 导出 --table record`（真实 xlsx 导出，自动剔除敏感字段）
- **模板**：`培小e 模板 record`（生成空录入模板 xlsx）
- **定时**：`--auto` 扫描输入目录自动入库
- **表名**：`--table` 支持 key（`leader/plan/quota/record`）和全表名（`pxe_*`）

## 配置说明

编辑 `scripts/config.js`：

1. `api.baseUrl` — 后端接口地址（`http://实际IP:端口/api/HuangDao/training`）
2. `api.apiSecret` — 服务端 app.api-secret
3. `admin.credential` — 管理员密码
4. `outDir` — 产物（HTML/导出Excel/建议归档）输出目录
5. `autoInbox` — cron 扫描目录

认证优先级：`--account/--credential` 参数 > 交互输入 > config.js 管理员默认。

## 建议规则参考

培小e 建议规则引擎的设计假定培训计划中 `matching_rules` 字段包含如下结构（兼容单层 JSON）：

```json
{ "cadreLevel": "正科级", "role": "班站长", "prodHead": true }
```

也兼容 `target_group` 文本描述（如"各供电所正副所长、班组长"），经关键词提取自动匹配。
若实际数据格式与此不同，调整 `ai_advisor.js` 中 `parsePlanCriteria()` 即可。

> **注意**：发布时 config.js 中的 `apiSecret` 和 `admin.credential` 应为空占位，确保不泄露真实凭据到技能商城。
